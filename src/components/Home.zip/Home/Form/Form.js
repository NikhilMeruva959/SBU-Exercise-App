import React from "react";
import { makeStyles } from "@material-ui/core/styles";

import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Slider from "@material-ui/core/Slider";
import Typography from "@material-ui/core/Typography";
import "./Form.css";

const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: "40%",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

let i = 0;
const Form = ({ types }) => {
  types.map((type) => console.log(type));
  const classes = useStyles();
  return (
    <form noValidate onSubmit={(e) => e.preventDefault()} clas>
      <FormControl className={classes.formControl}>
        <TextField
          style={{ marginTop: "5px" }}
          variant="outlined"
          margin="normal"
          required
          fullWidth
          label="Activity name"
          name="name"
        />
        <div style={{ marginTop: "20px", marginBottom: "30px" }}>
          <Typography id="discrete-slider" gutterBottom>
            Type
          </Typography>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            style={{ minWidth: "100%" }}
            name="type"
          >
            {types.map((type) => (
              <MenuItem value={i++}>{type}</MenuItem>
            ))}
          </Select>
        </div>
        <Typography id="discrete-slider" gutterBottom>
          Duration
        </Typography>
        <Button
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
          className="button"
        >
          Add activity
        </Button>
      </FormControl>
    </form>
  );
};

export default Form;
