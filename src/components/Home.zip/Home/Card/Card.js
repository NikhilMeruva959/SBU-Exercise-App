import React from "react";
import Form from "../Form/Form";
import "./Card.css";
import Button from "@material-ui/core/Button";

const Card = ({ type }) => {
  const [openForm, setOpenForm] = React.useState(false);
  const displayForm = () => {
    setOpenForm(true);
  };

  const cancelForm = () => {
    console.log("cancel");
    setOpenForm(false);
  };

  const data = {
    Arms: ["a", "b"],
    Chest: ["c", "d"],
    Shoulders: ["e", "f"],
    Legs: ["g", "h"],
    Back: ["i", "j"],
    Abs: ["k", "l"],
  };

  let types = data[type];

  return (
    <div className="card" id="card" onClick={displayForm}>
      <div>
        <h3>{type}</h3>
        {openForm && (
          <div>
            <Form types={types} />
            <br />
            <Button
              type="submit"
              fullWidth
              variant="outlined"
              color="secondary"
              className="button"
              onClick={cancelForm}
            >
              Cancel
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Card;
